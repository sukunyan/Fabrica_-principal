package Vista;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import Modelo.Coches;
import Modelo.ImagenUsuario;
import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/insertar")
public class Insertar {

    Coches coches = new Coches();

    @GetMapping
    public ModelAndView AbrirInsertar() {
        return new ModelAndView("insertar");
    }

    @PostMapping
    @ResponseBody
    public ResponseEntity<Map<String, String>> InsertarCoche(
            @RequestParam String marca,
            @RequestParam String modelo,
            @RequestParam LocalDate anio,
            @RequestParam String matricula,
            @RequestParam String numChasis,
            HttpSession session) {
    	
    	String usuarioActual = (String) session.getAttribute("usuario");
    	ImagenUsuario.obtenerImagenUsuario(usuarioActual);
    	
        Map<String, String> response = new HashMap<>();
    	
        if (usuarioActual == null) {
            response.put("error", "Usuario no autenticado. Por favor, inicie sesión.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    
        coches.setMarca(marca);
        coches.setModelo(modelo);
        coches.setFecha(anio.toString());
        coches.setMatricula(matricula);
        coches.setNumChasis(numChasis);

        try (Connection conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1/fabrica", "root", "");
             Statement consulta = conexion.createStatement()) {

            String sql = "insert into coches(marca, modelo, anio, matricula, numChasis) values ('" +
                    coches.getMarca() + "', '" +
                    coches.getModelo() + "', '" +
                    coches.getFecha() + "', '" +
                    coches.getMatricula() + "', '" +
                    coches.getNumChasis() + "')";

            System.out.println("insert into coches(marca, modelo, anio, matricula, numChasis)" + 
            " values('" + coches.getMarca() + "', '" + 
            coches.getModelo() + "', '" + 
            coches.getFecha() + "', " + "'" + 
            coches.getMatricula() + "', '" + coches.getNumChasis() + "');");
            consulta.executeUpdate(sql);

            response.put("mensaje", "Coche guardado correctamente");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            e.printStackTrace();
            response.put("error", "Error al guardar el coche: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
