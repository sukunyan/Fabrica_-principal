package Vista;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import Modelo.ImagenUsuario;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/panel")
public class Panel {
    
	@GetMapping
    public ModelAndView mostrarPanel(HttpSession session) {
		
		String usuarioActual = (String) session.getAttribute("usuario");
    	ImagenUsuario.obtenerImagenUsuario(usuarioActual);
    	
        return new ModelAndView("panel"); 
    }
	
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
	
}
